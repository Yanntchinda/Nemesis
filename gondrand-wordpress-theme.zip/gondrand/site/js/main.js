/* TRAVEX GLOBAL FORWARDING France site logic */
(function () {
  const BASE = window.BASE || "";
  const PAGE = window.PAGE || "";
  const LANG = localStorage.getItem("g-lang") === "en" ? "en" : "fr";

  const I18N = {
    fr: {
      nav_home: "Accueil", nav_company: "Entreprise", nav_services: "Services",
      nav_quote: "Devis", nav_contact: "Contact", nav_jobs: "Espace emploi",
      nav_locations: "Emplacements", nav_rfq: "Demande de cotation",
      svc_road: "Transport terrestre", svc_air: "Fret aérien", svc_sea: "Fret maritime",
      svc_special: "Trafics spéciaux", svc_customs: "Douane",
      svc_vat: "TVA / Représentation fiscale", svc_vat_short: "TVA/DOUANES",
      read_more: "Lire la suite →", read_more_colon: "Lire la suite : →",
      slide_road: "Nous traitons votre transport avec le professionnalisme et la minutie que vous pouvez attendre.",
      slide_air: "Avec nos solutions d'expédition de fret aérien, nous fournissons la rapidité et la fiabilité dont vous avez besoin pour votre expédition de fret aérien.",
      slide_sea: "Quels que soient votre origine ou votre destination, la taille de votre cargaison ou sa complexité, nos normes de qualité mondiales et nos systèmes éprouvés garantissent un service sûr et fiable pour une livraison à temps.",
      slide_special: "L'efficacité et le haut niveau sont la clé de votre succès. Nous avons l'expérience nécessaire pour gérer vos besoins en logistique et en transport d'un endroit à un autre. Peu importe quelle taille.",
      slide_customs: "Les règles applicables aux douanes et au commerce extérieur sont en augmentation constante. En nous conformant aux lois et réglementations européennes, nous pouvons vous offrir une valeur ajoutée positive.",
      slide_vat: "Vous êtes un entrepreneur étranger sans numéro de TVA belge et vous réalisez néanmoins un bénéfice substantiel en Belgique ? Notre service de représentation fiscale vous aide à vous conformer très facilement à la réglementation en matière de TVA.",
      about_sub: "Logistique depuis 1866",
      about_p1: "Le service qui nous est offert va bien au-delà de la gestion courante des commandes de logistique et de transport. Nous donnons une touche personnelle à tout ce que nous faisons grâce à notre personnel, qui soutient ce service sur mesure. Ils s’adaptent à vos besoins et non l’inverse.",
      about_p2: "Nous voulons apprendre à vous connaître – et vous devriez également nous connaître personnellement. Nous avons l’intention de créer une relation de confiance à long terme avec vous, comme nous le faisons avec tous nos clients depuis des années, voire des décennies.",
      loc_title: "Emplacements",
      loc_lead: "Un réseau d’agences de métropole, d’outre-mer et de frontière suisse. Sélectionnez une lettre.",
      svc_specials: "Services spéciaux",
      svc_specials_lead: "En tant que membre d’un réseau d’investisseurs internationaux, nous disposons des ressources financières et logistiques nécessaires à la définition et à la réalisation des objectifs de nos clients, tout en les accompagnant tout au long du processus.",
      about_us: "About us",
      card_about: "Le service qui nous est offert va bien au-delà de la gestion courante des commandes de logistique et de transport.",
      card_road: "Une organisation qui vous propose des services de porte à porte sur tout le territoire de l’Ancien Monde.",
      card_air: "Notre équipe de fret aérien vous rassure en sachant que vos marchandises sont entre de bonnes mains.",
      card_sea: "Nos professionnels du fret maritime tirent parti de leur vaste expérience pour gérer les flux de marchandises.",
      card_special: "L’activité inhérente au transport exceptionnel est adossée à un cabinet spécifique pour l’étude et la mise.",
      card_customs: "Ainsi, vos marchandises sont placées sous un régime suspensif de taxes, jusqu’à la destination finale que vous aurez choisie.",
      all_locations: "Toutes les agences",
      group: "NOTRE GROUPE D'ENTREPRISES",
      downloads: "Téléchargements",
      terms: "Conditions générales",
      containers: "Dimensions conteneurs",
      ges: "Bilan émissions GES",
      airlines: "Codes compagnies aériennes",
      vat_ecom: "TVA & E-Commerce",
      customs_form: "Douanes & formalités",
      network: "Réseau Travex Global Forwarding",
      hq: "Siège",
      legal: "Mentions légales",
      privacy: "Politique de confidentialité",
      rights: "© 2026 Travex Global Forwarding • Tous droits réservés.",
      since: "Logistique depuis 1866",
      cookie: "Nous utilisons des cookies et d'autres technologies sur notre site. Certains sont essentiels, d'autres nous aident à améliorer votre expérience. Les services Google (Maps, YouTube) ne sont chargés qu'après consentement. Plus d'informations dans notre politique de confidentialité.",
      accept: "Accepter",
      essential: "Cookies essentiels",
      quote_title: "Demander un devis gratuit",
      transport_type: "Type de transport",
      transport_type_ph: "Type de Transport",
      warehousing: "Entreposage",
      air_t: "Transport aérien",
      sea_t: "Transport maritime",
      multi_t: "Transport multimodal",
      road_t: "Transport terrestre",
      incoterms: "Conditions de vente",
      from_city: "Ville de départ",
      to_city: "Ville d'arrivée",
      weight: "Poids (kg)",
      email: "E-mail",
      privacy_ok: "Politique de confidentialité acceptée.",
      quote_ext: "Pour une version étendue du formulaire, cliquez ici.",
      click_here: "cliquez ici",
      send: "Envoyer →",
      quote_ok: "Votre demande a bien été transmise. Un commercial Travex Global Forwarding vous répondra dans les plus brefs délais.",
      quote_company: "Société", quote_phone: "Téléphone", quote_contact: "Contact",
      quote_from: "Départ", quote_to: "Arrivée", quote_from_country: "Pays (départ)", quote_to_country: "Pays (arrivée)",
      quote_client: "Données du client", quote_pack: "Colis", quote_parcel: "Type de colis",
      quote_dimensions: "Dimensions (L × l × H)", quote_dangerous: "Marchandise dangereuse", quote_comments: "Commentaires",
      special_title: "Qu'est-ce qui nous rend spécial ?",
      special_lead: "En tant que société européenne présente dans le monde entier, nous proposons à nos clients un portefeuille de services complet.",
      pack: "Emballage et stockage", pack_p: "Conditionnement et protection de vos marchandises.",
      ware: "Service d'entreposage", ware_p: "Plateformes sécurisées en France et à l'international.",
      road_f: "Transport terrestre", road_p: "Groupage et lots complets sur l'Ancien Monde.",
      logi: "Services logistiques", logi_p: "Pilotage de flux de bout en bout.",
      tel: "Tél.",
      belgium: "Belgique", china: "Chine", czech: "Tchéquie", germany_ngl: "Allemagne (NGL)",
      germany_mon: "Allemagne (Monnard)", lux: "Luxembourg", mexico: "Mexique", morocco: "Maroc",
      nl: "Pays-Bas", nc: "Nouvelle-Calédonie", senegal: "Sénégal", spain: "Espagne",
      ch: "Suisse", tahiti: "Tahiti", turkey: "Turquie", uk: "Royaume-Uni",
      home_crumb: "Accueil"
    },
    en: {
      nav_home: "Home", nav_company: "Company", nav_services: "Services",
      nav_quote: "Quote", nav_contact: "Contact", nav_jobs: "Careers",
      nav_locations: "Locations", nav_rfq: "Request a quote",
      svc_road: "Road freight", svc_air: "Air freight", svc_sea: "Sea freight",
      svc_special: "Special cargo", svc_customs: "Customs",
      svc_vat: "VAT / Tax representation", svc_vat_short: "VAT/CUSTOMS",
      read_more: "Read more →", read_more_colon: "Read more: →",
      slide_road: "We handle your transport with the professionalism and care you can expect.",
      slide_air: "With our air freight shipping solutions, we provide the speed and reliability you need for your air cargo.",
      slide_sea: "Whatever your origin or destination, cargo size or complexity, our global quality standards and proven systems ensure a safe, reliable, on-time service.",
      slide_special: "Efficiency and high standards are the key to your success. We have the experience to manage your logistics and transport needs from one place to another — whatever the size.",
      slide_customs: "Customs and foreign-trade rules keep growing. By complying with European laws and regulations, we deliver real added value.",
      slide_vat: "Are you a foreign entrepreneur without a Belgian VAT number, yet generating substantial activity in Belgium? Our tax representation service helps you comply easily with VAT regulations.",
      about_sub: "Logistics since 1866",
      about_p1: "The service we provide goes far beyond routine logistics and transport order handling. We give a personal touch to everything we do, thanks to our people who stand behind this tailored service. They adapt to your needs — not the other way around.",
      about_p2: "We want to get to know you — and you should get to know us personally. We intend to build a long-term relationship of trust with you, as we have done with our clients for years, even decades.",
      loc_title: "TRAVEX GLOBAL FORWARDING LOCATIONS",
      loc_lead: "A network of agencies in mainland France, overseas territories and on the Swiss border. Select a letter.",
      svc_specials: "Special services",
      svc_specials_lead: "As a member of an international investor network, we have the financial and logistics resources to define and achieve our clients’ goals, supporting them throughout the process.",
      about_us: "About us",
      card_about: "The service we provide goes far beyond routine logistics and transport order handling.",
      card_road: "An organisation offering door-to-door services across the whole of the Old World.",
      card_air: "Our air freight team gives you the reassurance that your goods are in good hands.",
      card_sea: "Our sea freight professionals draw on extensive experience to manage cargo flows.",
      card_special: "Oversized transport is backed by a dedicated desk for study and implementation.",
      card_customs: "Your goods are placed under a duty-suspension regime until the final destination you choose.",
      all_locations: "All locations",
      group: "OUR GROUP OF COMPANIES",
      downloads: "Downloads",
      terms: "General terms and conditions",
      containers: "Container dimensions",
      ges: "GHG emissions report",
      airlines: "Airline codes",
      vat_ecom: "VAT & E-Commerce",
      customs_form: "Customs & formalities",
      network: "Travex Global Forwarding network",
      hq: "Head office",
      legal: "Legal notice",
      privacy: "Privacy policy",
      rights: "© 2026 Travex Global Forwarding • All rights reserved.",
      since: "Logistics since 1866",
      cookie: "We use cookies and other technologies on our website. Some are essential, others help us improve your experience. Google services (Maps, YouTube) are only loaded after consent. More information in our privacy policy.",
      accept: "Accept",
      essential: "Essential cookies",
      quote_title: "Request a free quote",
      transport_type: "Type of transport",
      transport_type_ph: "Type of Transport",
      warehousing: "Warehousing",
      air_t: "Air transport",
      sea_t: "Sea transport",
      multi_t: "Multimodal transport",
      road_t: "Road transport",
      incoterms: "Terms of sale",
      from_city: "City of departure",
      to_city: "City of arrival",
      weight: "Weight (kg)",
      email: "E-mail",
      privacy_ok: "Privacy policy accepted.",
      quote_ext: "For an extended version of the form, click here.",
      click_here: "click here",
      send: "Send →",
      quote_ok: "Your request has been sent. A Travex Global Forwarding sales contact will get back to you shortly.",
      quote_company: "Company", quote_phone: "Phone", quote_contact: "Contact",
      quote_from: "Origin", quote_to: "Destination", quote_from_country: "Country (origin)", quote_to_country: "Country (destination)",
      quote_client: "Client details", quote_pack: "Parcel", quote_parcel: "Parcel type",
      quote_dimensions: "Dimensions (L × W × H)", quote_dangerous: "Dangerous goods", quote_comments: "Comments",
      special_title: "What makes us special?",
      special_lead: "As a European company with a worldwide presence, we offer our clients a complete portfolio of services.",
      pack: "Packing and storage", pack_p: "Conditioning and protection of your goods.",
      ware: "Warehousing service", ware_p: "Secure platforms in France and worldwide.",
      road_f: "Road freight", road_p: "Groupage and full loads across the Old World.",
      logi: "Logistics services", logi_p: "End-to-end flow management.",
      tel: "Tel.",
      belgium: "Belgium", china: "China", czech: "Czech Republic", germany_ngl: "Germany (NGL)",
      germany_mon: "Germany (Monnard)", lux: "Luxembourg", mexico: "Mexico", morocco: "Morocco",
      nl: "Netherlands", nc: "New Caledonia", senegal: "Senegal", spain: "Spain",
      ch: "Switzerland", tahiti: "Tahiti", turkey: "Turkey", uk: "United Kingdom",
      home_crumb: "Home"
    }
  };

  function t(key) {
    const cms = window.GONDRAND_CMS || {};
    if (cms[key]) return cms[key];
    return (I18N[LANG] && I18N[LANG][key]) || (I18N.fr[key]) || key;
  }

  const ICONS = {
    truck: `<svg viewBox="0 0 24 24"><rect x="1" y="7" width="15" height="10"/><path d="M16 11h4l3 3v3h-7"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="19" r="2"/></svg>`,
    plane: `<svg viewBox="0 0 24 24"><path d="M21 16v-2l-8-5V3.5A1.5 1.5 0 0 0 11.5 2 1.5 1.5 0 0 0 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z"/></svg>`,
    ship: `<svg viewBox="0 0 24 24"><path d="M3 17c1.5 1.5 4 3 9 3s7.5-1.5 9-3"/><path d="M4 13h16l-1.5 4H5.5z"/><path d="M6 13V8h4v5M12 13V6h4v7"/></svg>`,
    special: `<svg viewBox="0 0 24 24"><rect x="3" y="10" width="18" height="8"/><path d="M7 10V7h10v3"/><circle cx="7" cy="20" r="2"/><circle cx="17" cy="20" r="2"/></svg>`,
    customs: `<svg viewBox="0 0 24 24"><path d="M4 4h16v4H4z"/><path d="M6 8v12M18 8v12M6 20h12"/><path d="M9 12h6M9 16h6"/></svg>`,
    tax: `<svg viewBox="0 0 24 24"><path d="M6 3h9l3 3v15H6z"/><path d="M15 3v4h4"/><path d="M9 13h6M9 17h4"/></svg>`
  };

  const NAV = [
    { href: "index.html", label: t("nav_home"), id: "home" },
    { href: "entreprise/index.html", label: t("nav_company"), id: "entreprise" },
    {
      label: t("nav_services"), id: "services", children: [
        { href: "services/luftfracht-2/", label: t("svc_road") },
        { href: "services/ueber-uns/", label: t("svc_air") },
        { href: "services/beratung-2/", label: t("svc_sea") },
        { href: "services/seefracht-2/", label: t("svc_special") },
        { href: "services/zoll-2/", label: t("svc_customs") },
        { href: "representation-fiscale/index.html", label: t("svc_vat") }
      ]
    },
    { href: "demande-de-cotation/index.html", label: t("nav_quote"), id: "devis" },
    { href: "contact/index.html", label: t("nav_contact"), id: "contact" }
  ];


  // Locations are intentionally empty by default. They are supplied by WordPress
  // only when the administrator adds them in the Travex editor.
  const LOCS = { R: [] };


  function url(path) {
    if (!path || path === "index.html") return BASE ? BASE + "index.html" : "index.html";
    return BASE + path;
  }

  function headerHTML() {
    const links = NAV.map(item => {
      if (item.children) {
        return `<div class="drop">
          <span>${item.label} ▾</span>
          <div class="drop-menu">${item.children.map(c => `<a href="${url(c.href)}">${c.label}</a>`).join("")}</div>
        </div>`;
      }
      const active = item.id === PAGE ? "active" : "";
      return `<a class="${active}" href="${url(item.href)}">${item.label}</a>`;
    }).join("");

    return `
    <div class="topbar">
      <div class="wrap">
        <div class="lang">
          <button type="button" class="lang-btn${LANG === "fr" ? " on" : ""}" data-lang="fr">FR</button>
          <button type="button" class="lang-btn${LANG === "en" ? " on" : ""}" data-lang="en">EN</button>
        </div>
        <div class="top-links">
          <a href="${url("demande-de-cotation/index.html")}">${t("nav_rfq")}</a>
        </div>
      </div>
    </div>
    <header class="header">
      <div class="wrap">
        <a class="logo" href="${url("index.html")}" aria-label="Travex Global Forwarding accueil">
          <img src="${window.GONDRAND_LOGO || ((window.GONDRAND_ASSETS || BASE) + "images/logo-travex.png")}" alt="TRAVEX GLOBAL FORWARDING">
        </a>
        <button class="burger" id="burger" aria-label="Menu">☰</button>
        <nav class="nav" id="nav">${links}</nav>
      </div>
    </header>`;
  }

  function brandsHTML() {
    const items = Array.isArray(window.GONDRAND_BRANDS) ? window.GONDRAND_BRANDS : [];
    if (!items.length) {
      return `<a class="brand" href="${url("index.html")}">TRAVEX<small>GLOBAL FORWARDING</small></a>`;
    }
    return items.map(b => {
      const href = b.url || url("index.html");
      const img = b.image ? `<img src="${b.image}" alt="${b.name || "Logo"}">` : "";
      const name = b.name ? b.name : "";
      const sub = b.sub ? `<small>${b.sub}</small>` : "";
      return `<a class="brand" href="${href}">${img}${name}${sub}</a>`;
    }).join("");
  }

  function footerHTML() {
    return `
    <section class="group">
      <div class="wrap">
        <h2>${t("group")}</h2>
        <div class="brands">${brandsHTML()}</div>
      </div>
    </section>
    <footer class="footer">
      <div class="wrap">
        <div class="fgrid">
          <div>
            <h4>${t("downloads")}</h4>
            <ul>
              <li><a href="#">${t("terms")}</a></li>
              <li><a href="#">${t("containers")}</a></li>
              <li><a href="#">${t("ges")}</a></li>
              <li><a href="#">${t("airlines")}</a></li>
              <li><a href="#">${t("vat_ecom")}</a></li>
              <li><a href="#">${t("customs_form")}</a></li>
            </ul>
          </div>
          <div>
            <h4>${t("network")}</h4>
            <div class="countries">
              <span>Allemagne</span><span>France</span><span>Suisse</span>
            </div>
          </div>
          <div>
            <h4>${t("hq")}</h4>
            <p>Im Brünnel 2<br>77871 Renchen</p>
            <p style="margin-top:12px"><a href="${url("mentions-legales/index.html")}">${t("legal")}</a><br>
            <a href="${url("mentions-legales/index.html")}#privacy">${t("privacy")}</a></p>
          </div>
        </div>
        <div class="copy">
          <div class="certs"><span>IATA</span><span>OEA</span><span>ISO 9001</span></div>
          <div>© 2026 Travex Global Forwarding • Tous droits réservés.</div>
          <div>Logistique depuis 1866</div>
        </div>
      </div>
    </footer>
    <div class="cookie" id="cookie">
      <p>${t("cookie")} <a href="${url("mentions-legales/index.html")}#privacy">${t("privacy")}</a>.</p>
      <div class="actions">
        <button class="btn" id="cookie-ok">${t("accept")}</button>
        <button class="btn ghost" id="cookie-min">${t("essential")}</button>
      </div>
    </div>`;
  }

  function list(key, fallback) {
    const cms = window.GONDRAND_CMS || {};
    if (Array.isArray(cms[key]) && cms[key].length) return cms[key];
    if (typeof cms[key] === "string" && cms[key].trim()) {
      return cms[key].split(/\n/).map(s => s.trim()).filter(Boolean);
    }
    return fallback;
  }

  function options(items, placeholder) {
    const ph = placeholder ? `<option value="">${placeholder}</option>` : "";
    return ph + items.map(x => `<option>${x}</option>`).join("");
  }

  function quoteHTML(mode) {
    const compact = mode === true || mode === "compact";
    const full = mode === "full";
    const types = list("quote_types", [t("warehousing"), t("air_t"), t("sea_t"), t("multi_t"), t("road_t")]);
    const incos = list("quote_incoterms", ["EXW", "FCA", "FAS", "FOB", "CFR", "CIF", "CPT", "CIP", "DAP", "DPU", "DDP"]);
    const parcels = list("quote_parcels", ["Palette", "Carton", "Conteneur", "Caisse bois", "Sur-mesure", "Divers"]);
    const extra = compact ? "" : (full ? `
        <h3 style="color:var(--navy);margin:18px 0 10px">${t("quote_client")}</h3>
        <div class="grid-2">
          <div class="row"><label>${t("quote_company")}</label><input name="company" required></div>
          <div class="row"><label>${t("email")}</label><input name="email" type="email" required></div>
          <div class="row"><label>${t("quote_phone")}</label><input name="phone"></div>
          <div class="row"><label>${t("quote_contact")}</label><input name="contact"></div>
        </div>
        <h3 style="color:var(--navy);margin:18px 0 10px">${t("quote_from")}</h3>
        <div class="grid-2">
          <div class="row"><label>${t("from_city")}</label><input name="from_city" required></div>
          <div class="row"><label>${t("quote_from_country")}</label><input name="from_country" required></div>
        </div>
        <h3 style="color:var(--navy);margin:18px 0 10px">${t("quote_to")}</h3>
        <div class="grid-2">
          <div class="row"><label>${t("to_city")}</label><input name="to_city" required></div>
          <div class="row"><label>${t("quote_to_country")}</label><input name="to_country" required></div>
        </div>
        <h3 style="color:var(--navy);margin:18px 0 10px">${t("quote_pack")}</h3>
        <div class="grid-2">
          <div class="row"><label>${t("quote_parcel")}</label><select name="parcel" required>${options(parcels, t("quote_parcel"))}</select></div>
          <div class="row"><label>${t("weight")}</label><input name="weight" type="number" min="0"></div>
          <div class="row"><label>${t("quote_dimensions")}</label><input name="dimensions" placeholder="cm"></div>
          <div class="row"><label>${t("quote_dangerous")}</label><select name="dangerous"><option>Non</option><option>Oui</option></select></div>
        </div>
        <div class="row"><label>${t("quote_comments")}</label><textarea name="comments" rows="4"></textarea></div>
        ` : `
        <div class="grid-2">
          <div class="row"><label>${t("from_city")}</label><input name="from" required></div>
          <div class="row"><label>${t("to_city")}</label><input name="to" required></div>
        </div>
        <div class="grid-2">
          <div class="row"><label>${t("weight")}</label><input name="weight" type="number" min="0"></div>
          <div class="row"><label>${t("email")}</label><input name="email" type="email" required></div>
        </div>`);
    return `
    <div class="quote" id="devis">
      ${full ? "" : `<h2>${t("quote_title")}</h2>`}
      <form id="quote-form" action="${url("send.php")}" method="post">
        <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
        <div class="${full ? "row" : "grid-2"}">
          <div class="row">
            <label>${t("transport_type")}</label>
            <select name="type" required>${options(types, t("transport_type_ph"))}</select>
          </div>
          ${full ? "" : `<div class="row">
            <label>${t("incoterms")}</label>
            <select name="incoterms"><option value="">${t("incoterms")}</option>${incos.map(x => `<option>${x}</option>`).join("")}</select>
          </div>`}
        </div>
        ${extra}
        ${full ? `<div class="row"><label>${t("incoterms")}</label><select name="incoterms" required>${options(incos, t("incoterms"))}</select></div>` : ""}
        ${compact ? `<div class="row"><label>${t("email")}</label><input name="email" type="email" required></div>` : ""}
        <div class="row">
          <label class="check"><input type="checkbox" required> <span><a href="${url("mentions-legales/index.html")}#privacy">${t("privacy")}</a> — ${t("privacy_ok")}</span></label>
        </div>
        ${full ? "" : `<p style="font-size:12px;color:#64748b;margin-bottom:12px">${t("quote_ext").replace(t("click_here"), `<a href="${url("demande-de-cotation/index.html")}">${t("click_here")}</a>`)}</p>`}
        <button class="btn ghost" type="submit">${t("send")}</button>
      </form>
      <div class="okbox" id="quote-ok">${t("quote_ok")}</div>
    </div>`;
  }

  function specialHTML() {
    return `
    <div>
      <div class="bar"></div>
      <h2>${t("special_title")}</h2>
      <p class="lead" style="margin-bottom:18px">${t("special_lead")}</p>
      <div class="specials">
        <div class="feat"><div class="ico">▣</div><div><h4>${t("pack")}</h4><p>${t("pack_p")}</p></div></div>
        <div class="feat"><div class="ico">⌂</div><div><h4>${t("ware")}</h4><p>${t("ware_p")}</p></div></div>
        <div class="feat"><div class="ico">▭</div><div><h4>${t("road_f")}</h4><p>${t("road_p")}</p></div></div>
        <div class="feat"><div class="ico">◈</div><div><h4>${t("logi")}</h4><p>${t("logi_p")}</p></div></div>
      </div>
    </div>`;
  }

  window.Travex = { ICONS, LOCS, quoteHTML, specialHTML, url };

  function mountChrome() {
    const h = document.getElementById("site-header");
    const f = document.getElementById("site-footer");
    if (h) h.outerHTML = headerHTML();
    if (f) f.outerHTML = footerHTML();
    const burger = document.getElementById("burger");
    const nav = document.getElementById("nav");
    if (burger && nav) burger.onclick = () => nav.classList.toggle("open");
    const cookie = document.getElementById("cookie");
    if (cookie && !localStorage.getItem("g-cookie")) cookie.classList.add("show");
    const ok = document.getElementById("cookie-ok");
    const min = document.getElementById("cookie-min");
    function hide() { localStorage.setItem("g-cookie", "1"); cookie.classList.remove("show"); }
    if (ok) ok.onclick = hide;
    if (min) min.onclick = hide;
    document.querySelectorAll(".lang-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const next = btn.getAttribute("data-lang") === "en" ? "en" : "fr";
        localStorage.setItem("g-lang", next);
        location.reload();
      });
    });
  }

  function applyI18n() {
    document.documentElement.lang = LANG;
    document.querySelectorAll("[data-i18n]").forEach(el => {
      const key = el.getAttribute("data-i18n");
      if (I18N[LANG] && I18N[LANG][key]) el.textContent = I18N[LANG][key];
    });
    document.querySelectorAll("h2").forEach(el => {
      if (/gondrand/i.test(el.textContent) && /emplacements|locations/i.test(el.textContent)) {
        el.textContent = LANG === "en" ? "TRAVEX GLOBAL FORWARDING LOCATIONS" : "TRAVEX GLOBAL FORWARDING EMPLACEMENTS";
      }
    });
    document.querySelectorAll(".crumbs a").forEach(a => {
      if (/Accueil|Home/.test(a.textContent.trim())) a.textContent = t("home_crumb");
    });
    if (LANG !== "en") return;
    const extra = {
      "GROUPAGE": "GROUPAGE",
      "Vêtements suspendus": "Hanging garments",
      "LOCATION": "CHARTER / HIRE",
      "Module de performance du fret routier": "Road freight performance module",
      "Module de performance de fret aérien": "Air freight performance module",
      "Module de performance du fret maritime": "Sea freight performance module",
      "Module de performance des trafics spéciaux": "Special cargo performance module",
      "Spécialiste sur les DROM-COM": "Specialist for French overseas territories",
      "Historique": "History",
      "Contact & emplacements": "Contact & locations",
      "Paris — Direction générale": "Paris — Head office",
      "Recevez des devis gratuits": "Get free quotes",
      "Mentions légales": "Legal notice",
      "Représentation fiscale": "Tax representation",
      "Services": "Services",
      "Nos services": "Our services",
      "DE VALEUR   EXPRESS   IMPORTANT": "HIGH VALUE   EXPRESS   IMPORTANT",
      "GRANDE VALEUR   RAPIDE   IMPORTANT": "HIGH VALUE   FAST   IMPORTANT",
      "GRANDE VALEUR · RAPIDE · IMPORTANT": "HIGH VALUE · FAST · IMPORTANT"
    };
    Object.keys(I18N.fr).forEach(k => {
      if (I18N.fr[k] && I18N.en[k] && I18N.fr[k] !== I18N.en[k]) extra[I18N.fr[k]] = I18N.en[k];
    });
    const walk = (node) => {
      if (node.nodeType === 3) {
        const trimmed = node.nodeValue.trim();
        if (extra[trimmed]) node.nodeValue = node.nodeValue.replace(trimmed, extra[trimmed]);
      } else if (node.nodeType === 1 && !/^(SCRIPT|STYLE|TEXTAREA|INPUT)$/.test(node.tagName)) {
        node.childNodes.forEach(walk);
      }
    };
    walk(document.body);
  }

  function bindQuote() {
    document.addEventListener("submit", (e) => {
      const form = e.target.closest("#quote-form");
      if (!form) return;
      e.preventDefault();
      const btn = form.querySelector('[type="submit"]');
      if (btn) btn.disabled = true;
      const action = form.getAttribute("action") || (BASE + "send.php");
      fetch(action, { method: "POST", body: new FormData(form) })
        .then(r => r.json().catch(() => ({ ok: false })))
        .then(data => {
          if (data && data.ok) {
            form.style.display = "none";
            const box = form.parentElement.querySelector(".okbox");
            if (box) box.classList.add("show");
          } else {
            alert(LANG === "en" ? "The message could not be sent. Please try again or email accueil.dg@gondrand.fr" : "L'envoi a échoué. Réessayez ou écrivez à accueil.dg@gondrand.fr");
            if (btn) btn.disabled = false;
          }
        })
        .catch(() => {
          alert(LANG === "en" ? "The message could not be sent. Please try again." : "L'envoi a échoué. Réessayez.");
          if (btn) btn.disabled = false;
        });
    });
  }

  function locItems() {
    if (Array.isArray(window.GONDRAND_LOCS) && window.GONDRAND_LOCS.length) {
      return window.GONDRAND_LOCS;
    }
    const out = [];
    Object.keys(LOCS).forEach(k => (LOCS[k] || []).forEach(x => out.push(x)));
    return out;
  }

  function flattenLocs(items) {
    const cards = [];
    let group = "";
    items.forEach(x => {
      const title = x.n || x.title || "";
      const address = x.a || x.address || "";
      const extra = x.nearby || x.text || "";
      if (title || address) cards.push({ title, address });
      String(extra).split(/\n/).forEach(line => {
        line = line.replace(/^[•📍📌*\-]+\s*/, "").trim();
        if (!line || /^Notre point/.test(line)) return;
        if (/Allemagne|France|Suisse/.test(line) && !/km/i.test(line)) {
          group = line.replace(/[\u{1F1E6}-\u{1F1FF}]/gu, "").trim();
          return;
        }
        const m = line.match(/^(.+?)\s+[–—-]\s+(.+)$/);
        if (m) cards.push({ title: m[1].trim(), address: (group ? group + "\n" : "") + m[2].trim() });
        else cards.push({ title: line, address: group || "" });
      });
    });
    return cards;
  }

  function renderLocations() {
    const grid = document.getElementById("loc-grid");
    if (!grid) return;
    const az = document.getElementById("az");
    if (az) az.style.display = "none";
    const items = flattenLocs(locItems());
    if (!items.length) {
      const section = grid.closest("#emplacements") || grid.closest("section");
      if (section) section.style.display = "none";
      return;
    }
    grid.className = "loc-grid";
    grid.innerHTML = items.map(x => `
      <article class="loc">
        <h3>${x.title || ""}</h3>
        <p>${(x.address || "").replace(/\n/g, "<br>")}</p>
      </article>`).join("");
  }

  function mountAZ() {
    renderLocations();
  }

  function isAndroid() {
    return /Android/i.test(navigator.userAgent || "");
  }

  function fitSlider() {
    // Desktop may use the active image height. Mobile/Android must NOT do that:
    // different image aspect ratios would make the hero grow and shrink.
    var hero = document.querySelector(".hero");
    var wrap = hero && hero.querySelector(".slides");
    if (!wrap) return;
    var mobile = isAndroid() || (window.matchMedia && window.matchMedia("(max-width: 980px)").matches);
    if (mobile) {
      document.documentElement.classList.toggle("travex-android", isAndroid());
      // Let the fixed CSS height (default 420px or the admin value) control it.
      wrap.style.height = "";
      wrap.style.minHeight = "";
      wrap.style.maxHeight = "";
      wrap.querySelectorAll(".slide-img").forEach(function (img) {
        img.style.position = "";
        img.style.width = "";
        img.style.height = "";
        img.style.maxWidth = "";
        img.style.display = "";
        img.style.objectFit = "";
        img.style.objectPosition = "";
      });
      return;
    }
    var active = wrap.querySelector(".slide.active") || wrap.querySelector(".slide");
    if (active) {
      var h = active.offsetHeight;
      if (h > 0) wrap.style.height = h + "px";
    }
  }

  function watchTravexBust() {
    const known = String(window.TRAVEX_BUST || "");
    const url = window.TRAVEX_BUST_URL;
    if (!known || !url) return;
    const hardReload = (newBust) => {
      try {
        document.cookie = "gondrand_bust=" + newBust + "; path=/; max-age=86400; SameSite=Lax";
        const s = window.sessionStorage;
        s && s.setItem("g-bust-reload", "1");
        // Bypass HTTP cache + bfcache + any CDN stale copy
        const current = window.location.pathname + window.location.search;
        const sep = current.indexOf("?") >= 0 ? "&" : "?";
        window.location.replace(current + sep + "_cb=" + Date.now() + window.location.hash);
      } catch (e) {
        window.location.reload(true);
      }
    };
    const check = () => {
      if (document.hidden) return; // save battery; check on visibilitychange instead
      const bustSep = url.indexOf("?") >= 0 ? "&" : "?";
      fetch(url + bustSep + "_=" + Date.now(), {
        cache: "no-store", credentials: "same-origin",
        headers: { "Cache-Control": "no-cache, no-store", "Pragma": "no-cache" }
      })
        .then(r => {
          // Force bypass if response says cache-hit
          var cc = (r.headers.get("cache-control") || "") + " " + (r.headers.get("x-litespeed-cache") || "");
          if (/hit|stale/i.test(cc)) {
            // retry with a random param to force miss
            return fetch(url + (url.indexOf("?") >= 0 ? "&" : "?") + "__cb=" + Math.random() + "&_=" + Date.now(), {
              cache: "no-store", credentials: "same-origin",
              headers: { "Cache-Control": "no-cache, no-store", "Pragma": "no-cache", "X-Cache-Bust": "1" }
            });
          }
          return r;
        })
        .then(r => r.json())
        .then(d => {
          if (d && d.bust && String(d.bust) !== known) hardReload(String(d.bust));
        })
        .catch(() => {});
    };
    // Immediate check on page restore from bfcache (Android back button)
    window.addEventListener("pageshow", (e) => {
      if (e.persisted) { hardReload(known); return; }
      check();
    });
    document.addEventListener("visibilitychange", () => { if (!document.hidden) check(); });
    window.addEventListener("focus", check);
    window.addEventListener("online", check);
    // Poll every 3 seconds (fast enough for LWS, cheap: tiny JSON)
    setInterval(check, 3000);
    // First check 500ms after load (so LWS has time to purge after admin save)
    window.setTimeout(check, 500);
  }

  function slider() {
    const slides = Array.from(document.querySelectorAll(".hero .slides .slide"));
    if (slides.length < 2) return;
    let i = Math.max(0, slides.findIndex(s => s.classList.contains("active")));
    if (i < 0) i = 0;
    const navs = document.querySelectorAll(".rev_slider_nav, .icon-card");
    let timer = null;
    let locked = false;

    const apply = () => {
      slides.forEach((s, k) => {
        const on = (k === i);
        if (on) {
          s.classList.add("active");
          s.style.opacity = "1";
          s.style.visibility = "visible";
          s.style.zIndex = "2";
        } else {
          s.classList.remove("active");
          s.style.opacity = "0";
          s.style.visibility = "hidden";
          s.style.zIndex = "1";
        }
      });
      navs.forEach((c, k) => c.classList.toggle("active", k === i));
      // Resize the wrapper after the active slide becomes visible.
      requestAnimationFrame(fitSlider);
      window.setTimeout(fitSlider, 950); // after fade
    };

    const show = (n) => {
      if (locked) return;
      locked = true;
      i = ((n % slides.length) + slides.length) % slides.length;
      apply();
      window.setTimeout(() => { locked = false; }, 700);
    };

    apply();
    window.setTimeout(fitSlider, 50);
    window.addEventListener("load", fitSlider);
    window.addEventListener("resize", () => { fitSlider(); });
    window.addEventListener("orientationchange", () => { window.setTimeout(fitSlider, 200); });

    navs.forEach((c, k) => c.addEventListener("click", (e) => {
      e.preventDefault();
      const idx = parseInt(c.getAttribute("data-slide"), 10);
      show(Number.isFinite(idx) && idx > 0 ? idx - 1 : k);
    }));
    const prev = document.querySelector(".hero-nav .prev");
    const next = document.querySelector(".hero-nav .next");
    if (prev) prev.addEventListener("click", (e) => { e.preventDefault(); show(i - 1); });
    if (next) next.addEventListener("click", (e) => { e.preventDefault(); show(i + 1); });

    // Touch swipe (horizontal only; ignore vertical scroll gestures)
    let startX = 0, startY = 0, tracking = false;
    const hero = document.querySelector(".hero");
    if (hero) {
      hero.addEventListener("touchstart", (e) => {
        const t = e.changedTouches[0];
        if (!t) return;
        startX = t.clientX; startY = t.clientY; tracking = true;
      }, { passive: true });
      hero.addEventListener("touchend", (e) => {
        if (!tracking) return; tracking = false;
        const t = e.changedTouches[0]; if (!t) return;
        const dx = t.clientX - startX;
        const dy = t.clientY - startY;
        if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) {
          show(i + (dx < 0 ? 1 : -1));
        }
      }, { passive: true });
    }

    const start = () => {
      if (timer) clearInterval(timer);
      timer = window.setInterval(() => show(i + 1), 5000);
    };
    start();
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) { if (timer) { clearInterval(timer); timer = null; } }
      else { apply(); start(); }
    });
    window.addEventListener("pageshow", () => { apply(); start(); });
  }

  function tabs() {
    document.querySelectorAll("[data-tabs]").forEach(root => {
      root.addEventListener("click", (e) => {
        const b = e.target.closest("button[data-tab]");
        if (!b) return;
        root.querySelectorAll("button[data-tab]").forEach(x => x.classList.toggle("on", x === b));
        root.parentElement.querySelectorAll(".panel").forEach(p => p.classList.toggle("on", p.id === b.dataset.tab));
      });
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    mountChrome();
    bindQuote();
    mountAZ();
    slider();
    fitSlider();
    watchTravexBust();
    tabs();
    applyI18n();
    window.addEventListener("resize", fitSlider);
    window.addEventListener("orientationchange", () => window.setTimeout(fitSlider, 250));
  });
})();
